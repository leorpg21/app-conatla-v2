@props(['value' => null])
<option value="value">{{ $slot }}</option>
