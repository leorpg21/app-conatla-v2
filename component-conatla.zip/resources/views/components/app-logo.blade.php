<div class="flex aspect-square size-8 items-center justify-center rounded-md bg-green-800 text-accent-foreground">
    <x-app-logo-icon class="size-5 fill-current text-white dark:text-black" />
</div>
<div :class="!collapseDesktop ? 'md:hidden' : 'ms-1 grid flex-1 text-start text-xl text-green-800'">
    <span class="mb-0.5 truncate leading-tight font-semibold">Conatla App</span>
</div>
