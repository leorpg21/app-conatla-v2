<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        @include('partials.default.head')  
    </head>
    <body class="h-screen flex">
        <!-- Lado Izquierdo (oculto en pantallas pequeñas) -->
        <div class="hidden lg:flex w-1/2 bg-green-900 text-white flex-col justify-between p-10">
            <div class="flex items-center gap-3">
                <!-- Logo -->
                <x-app-logo-icon class="size-8 fill-current text-white" />
                <h1 class="text-2xl font-semibold">Conatla App</h1>
            </div>
            
        </div>

        <!-- Lado Derecho -->
        <div class="flex w-full lg:w-1/2 items-center justify-center bg-white">
            {{ $slot }}
        </div>

    @livewireScripts
    </body>
</html>
