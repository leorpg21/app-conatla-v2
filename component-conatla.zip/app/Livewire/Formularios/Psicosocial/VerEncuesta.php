<?php

namespace App\Livewire\Formularios\Psicosocial;

use Livewire\Component;

class VerEncuesta extends Component
{
    public function render()
    {
        return view('livewire.formularios.psicosocial.ver-encuesta');
    }
}
