<?php

namespace App\Livewire\Formularios\AtencionCampo;

use Livewire\Component;

class VerEncuesta extends Component
{
    public function render()
    {
        return view('livewire.formularios.atencion-campo.ver-encuesta');
    }
}
